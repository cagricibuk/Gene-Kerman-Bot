import discord
from discord.ext import commands
import json
from datetime import datetime

intents = discord.Intents.default()
intents.members = True
intents.presences = True

bot = commands.Bot(command_prefix='!', intents=intents)

# JSON dosyasını yükle veya boş dictionary döndür
def load_play_times():
    try:
        with open('play_times.json', 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.decoder.JSONDecodeError):
        # Dosya yoksa veya JSONDecodeError hatası alınırsa boş bir dictionary döndür
        return {}

def save_play_times(play_times):
    with open('play_times.json', 'w') as f:
        json.dump(play_times, f, indent=4)

@bot.event
async def on_ready():
    print(f'Bot {bot.user} olarak giriş yaptı')
    play_times = load_play_times()
    start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    for guild in bot.guilds:
        for member in guild.members:
            playing_ksp = lambda presence: presence.activity and presence.activity.name == "Kerbal Space Program"
            if playing_ksp(member):
                member_id_str = str(member.id)
                if member_id_str not in play_times:
                    play_times[member_id_str] = {'name': member.name, 'sessions': []}
                play_times[member_id_str]['sessions'].append({'start_time': start_time})
                await send_log(member.guild, f"{member.name} oynamaya başladı (bot başlangıcı): Kerbal Space Program")
                print(f"{member.name} (ID: {member.id}) bot başlangıcında KSP oynuyor ve kayıt edildi.")
    
    save_play_times(play_times)

@bot.event
async def on_presence_update(before, after):
    play_times = load_play_times()

    # Kullanıcı KSP oynuyor mu diye kontrol et
    playing_ksp = lambda presence: presence.activity and presence.activity.name == "Kerbal Space Program"

    # Kullanıcı KSP oynamaya başladı
    if not playing_ksp(before) and playing_ksp(after):
        start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        member_id_str = str(after.id)
        if member_id_str not in play_times:
            play_times[member_id_str] = {'name': after.name, 'sessions': []}
        play_times[member_id_str]['sessions'].append({'start_time': start_time})
        save_play_times(play_times)
        await send_log(after.guild, f"{after.name} oynamaya başladı: Kerbal Space Program")
        print(f"{after.name} (ID: {after.id}) oynamaya başladı ve kayıt edildi.")

    # Kullanıcı KSP oynamayı bıraktı
    elif playing_ksp(before) and not playing_ksp(after):
        print(f"{before.id} Oynamayı bıraktı")
        member_id_str = str(before.id)
        if member_id_str in play_times:
            end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            last_session = play_times[member_id_str]['sessions'][-1]
            start_time = datetime.strptime(last_session['start_time'], '%Y-%m-%d %H:%M:%S')
            play_duration = datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S') - start_time

            hours, remainder = divmod(play_duration.total_seconds(), 3600)
            minutes, _ = divmod(remainder, 60)

            last_session['end_time'] = end_time
            last_session['duration_hours'] = int(hours)
            last_session['duration_minutes'] = int(minutes)
            save_play_times(play_times)

            duration_str = f"{int(hours)} saat {int(minutes)} dakika"
            await send_log(before.guild, f"{before.name} oynamayı bıraktı: Kerbal Space Program. Oturum süresi: {duration_str}")
            print(f"{before.name} (ID: {before.id}) oynamayı bıraktı ve oturum süresi kaydedildi: {duration_str}")
        else:
            print("Kayıtlarda yok")

async def send_log(guild, message):
    channel = discord.utils.get(guild.text_channels, name='ksp-log')
    if channel:
        await channel.send(message)

bot.run('MTI1OTYyMzM1MDEzMzg1NDIxOA.GwAZur.0-LxFAKsAELI_goBVHWsu1npvJrK57BzdgluOA')
